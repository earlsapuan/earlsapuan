﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TestCSVHelper.StudentSubjectModule;
using TestCSVHelper.SubjectModule;

namespace TestCSVHelper
{
    public partial class FormMain : Form
    {
        public FormMain()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FormMainStudent frmStudent = new FormMainStudent();
            frmStudent.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FormMainSubjects formMainSubjects = new FormMainSubjects();
            formMainSubjects.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            FormMainStudentSubjects formMainStudentSubjects = new FormMainStudentSubjects();
            formMainStudentSubjects.ShowDialog();
        }
    }
}
