﻿using CsvHelper;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestCSVHelper.Models;
using TestCSVHelper.View_Models;

namespace TestCSVHelper.DataAccess
{
    public static class StudentSubjectData
    {
        private static string filePath = "C:\\Users\\jayso\\OneDrive\\Desktop\\React\\TestCSVHelper\\TestCSVHelper\\studentsubject.csv";


        public static void AddStudentSubject(StudentSubject studentSubject)
        {
            var records = GetAllStudentSubjects();
            records.Add(studentSubject);
            WriteAllStudentSubjects(filePath, records);
        }

        public static List<StudentSubject> GetAllStudentSubjects()
        {

            using (var reader = new StreamReader(filePath))
            using (var csv = new CsvReader(reader, CultureInfo.InvariantCulture))
            {
                return csv.GetRecords<StudentSubject>().ToList();
            }
        }

        public static List<ViewStudentSubject> GetAllSubjectsByStudent(int studentId)
        {
            List<StudentSubject> list = new List<StudentSubject>();
            List<Subject> subjects = SubjectData.GetAllSubjects();
            //This list will be used as return value for the method.
            List<ViewStudentSubject> returnList = new List<ViewStudentSubject>();
            using (var reader = new StreamReader(filePath))
            using (var csv = new CsvReader(reader, CultureInfo.InvariantCulture))
            {
                list = csv.GetRecords<StudentSubject>().Where(x => x.StudentId == studentId).ToList();
            }

            //Loops through all the List the came from the excel file.
            foreach (var item in list)
            {
                //Declares an instance of ViewStudentSubject to be added to the list.
                ViewStudentSubject viewStudentSubject = new ViewStudentSubject();
                //The FirstOrDefault simply return a single intance of the list that filters using the SubjectId
                viewStudentSubject.Subject = subjects.FirstOrDefault(x => x.SubjectId == item.SubjectId).SubjectName;
                viewStudentSubject.Grade = item.Grade;

                //Add the instance of the ViewStudentSubject in the list for return.
                returnList.Add(viewStudentSubject);
            }

            return returnList;
        }

        public static void WriteAllStudentSubjects(string filePath, List<StudentSubject> records)
        {
            //Gets the file
            using (var writer = new StreamWriter(filePath))
            //Writes the list to the excel
            using (var csv = new CsvWriter(writer, CultureInfo.InvariantCulture))
            {
                csv.WriteRecords(records);
            }
        }
    }


}
