﻿using CsvHelper;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestCSVHelper.Models;

namespace TestCSVHelper.DataAccess
{
    public static class StudentData
    {
        private static string filePath = "C:\\Users\\jayso\\OneDrive\\Desktop\\React\\TestCSVHelper\\TestCSVHelper\\student.csv";

        //Add a student row to the excel file.
        public static void AddStudent(Student student)
        {
            //Gets all the students from the excel
            var records = GetAllStudents();

            //Add the new student to the list
            records.Add(student);

            //Writes all the list to the excel file
            WriteAllStudents(filePath, records);
        }

        public static List<Student> GetAllStudents()
        {
            //Uses the StreamReader class to get access to the excel file.
            using (var reader = new StreamReader(filePath))
            //Uses the CsvReader class to get the actual data inside the excel file. Requires an instance of StreamReader.
            using (var csv = new CsvReader(reader, CultureInfo.InvariantCulture))
            {
                //Gets the records of the csv using the GetRecords method but converts it first to a List of Students before it returns to the method.
                return csv.GetRecords<Student>().ToList();
            }
        }

        public static List<Student> GetAllStudentsNameSearch(string searchName)
        {
            //Uses the StreamReader class to get access to the excel file.
            using (var reader = new StreamReader(filePath))
            //Uses the CsvReader class to get the actual data inside the excel file. Requires an instance of StreamReader.
            using (var csv = new CsvReader(reader, CultureInfo.InvariantCulture))
            {
                //Gets the records of the csv using the GetRecords method but converts it first to a List of Students before it returns to the method.
                //The .Where filters the list base on the LastName.
                return csv.GetRecords<Student>().Where(x => x.LastName.ToLower().Contains(searchName.ToLower())).ToList();
            }
        }

        public static Student GetStudentById(int studentId)
        {
            //Uses the StreamReader class to get access to the excel file.
            using (var reader = new StreamReader(filePath))
            //Uses the CsvReader class to get the actual data inside the excel file. Requires an instance of StreamReader.
            using (var csv = new CsvReader(reader, CultureInfo.InvariantCulture))
            {
                //Gets the records of the csv using the GetRecords method but converts it first to a List of Students before it returns to the method.
                //The .FirstOrDefault returns a single instance of the list filters the list base on the StudentId.
                return csv.GetRecords<Student>().FirstOrDefault(x=>x.StudentId == studentId);
            }
        }

        public static void WriteAllStudents(string filePath, List<Student> records)
        {
            //Uses the StreamReader class to get access to the excel file.
            using (var writer = new StreamWriter(filePath))
            //Uses the CsvReader class to get the actual data inside the excel file. Requires an instance of StreamReader.
            using (var csv = new CsvWriter(writer, CultureInfo.InvariantCulture))
            {
                //The WriteRecords puts the list to the excel file.
                csv.WriteRecords(records);
            }
        }
    }
}
