﻿using CsvHelper;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestCSVHelper.Models;

namespace TestCSVHelper.DataAccess
{
    public static class SubjectData
    {
        private static string filePath = "C:\\Users\\jayso\\OneDrive\\Desktop\\React\\TestCSVHelper\\TestCSVHelper\\subject.csv";

        public static void AddSubject(Subject subject)
        {
            var records = GetAllSubjects();
            records.Add(subject);
            WriteAllSubjects(filePath, records);
        }

        public static List<Subject> GetAllSubjects()
        {

            using (var reader = new StreamReader(filePath))
            using (var csv = new CsvReader(reader, CultureInfo.InvariantCulture))
            {
                return csv.GetRecords<Subject>().ToList();
            }
        }

        public static void WriteAllSubjects(string filePath, List<Subject> records)
        {
            //Gets the file
            using (var writer = new StreamWriter(filePath))
            //Writes the list to the excel
            using (var csv = new CsvWriter(writer, CultureInfo.InvariantCulture))
            {
                csv.WriteRecords(records);
            }
        }
    }
}
