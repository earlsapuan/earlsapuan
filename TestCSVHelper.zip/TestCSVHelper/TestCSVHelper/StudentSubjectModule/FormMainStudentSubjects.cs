﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TestCSVHelper.DataAccess;
using TestCSVHelper.Models;
using TestCSVHelper.SubjectModule;

namespace TestCSVHelper.StudentSubjectModule
{
    public partial class FormMainStudentSubjects : Form
    {
        public FormMainStudentSubjects()
        {
            InitializeComponent();
        }

        private void FormMainStudentSubjects_Load(object sender, EventArgs e)
        {
            LoadStudentSubjects();
        }

        private void LoadStudentSubjects()
        {
            List<StudentSubject> studentSubjects = new List<StudentSubject>();
            studentSubjects = StudentSubjectData.GetAllStudentSubjects();

            dataGridViewStudentSubjects.DataSource = null;
            dataGridViewStudentSubjects.DataSource = studentSubjects;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FormAddStudentSubject formAddStudentSubject = new FormAddStudentSubject();
            if (formAddStudentSubject.ShowDialog() == DialogResult.OK)
            {
                LoadStudentSubjects();
            }
        }
    }
}
