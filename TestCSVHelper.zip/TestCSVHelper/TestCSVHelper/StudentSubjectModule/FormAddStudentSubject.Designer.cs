﻿namespace TestCSVHelper.StudentSubjectModule
{
    partial class FormAddStudentSubject
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            label2 = new Label();
            dataGridViewStudents = new DataGridView();
            textBoxSearch = new TextBox();
            groupBox2 = new GroupBox();
            label1 = new Label();
            dataGridViewSubjects = new DataGridView();
            textBox1 = new TextBox();
            groupBox3 = new GroupBox();
            label5 = new Label();
            textBoxId = new TextBox();
            button1 = new Button();
            label4 = new Label();
            textBoxGrade = new TextBox();
            labelSubject = new Label();
            label6 = new Label();
            labelStudentName = new Label();
            label3 = new Label();
            labelStudentId = new Label();
            labelSubjectId = new Label();
            label7 = new Label();
            label8 = new Label();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridViewStudents).BeginInit();
            groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridViewSubjects).BeginInit();
            groupBox3.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(label7);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(dataGridViewStudents);
            groupBox1.Controls.Add(textBoxSearch);
            groupBox1.Location = new Point(42, 61);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(577, 357);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Student List";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(6, 31);
            label2.Name = "label2";
            label2.Size = new Size(107, 15);
            label2.TabIndex = 10;
            label2.Text = "Last Name Search: ";
            // 
            // dataGridViewStudents
            // 
            dataGridViewStudents.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewStudents.Location = new Point(6, 61);
            dataGridViewStudents.Name = "dataGridViewStudents";
            dataGridViewStudents.Size = new Size(553, 257);
            dataGridViewStudents.TabIndex = 8;
            dataGridViewStudents.CellDoubleClick += dataGridViewStudents_CellDoubleClick;
            // 
            // textBoxSearch
            // 
            textBoxSearch.Location = new Point(119, 28);
            textBoxSearch.Name = "textBoxSearch";
            textBoxSearch.Size = new Size(440, 23);
            textBoxSearch.TabIndex = 9;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(label8);
            groupBox2.Controls.Add(label1);
            groupBox2.Controls.Add(dataGridViewSubjects);
            groupBox2.Controls.Add(textBox1);
            groupBox2.Location = new Point(639, 61);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(577, 357);
            groupBox2.TabIndex = 1;
            groupBox2.TabStop = false;
            groupBox2.Text = "Subject List";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(6, 31);
            label1.Name = "label1";
            label1.Size = new Size(125, 15);
            label1.TabIndex = 10;
            label1.Text = "Subject Name Search: ";
            // 
            // dataGridViewSubjects
            // 
            dataGridViewSubjects.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewSubjects.Location = new Point(6, 61);
            dataGridViewSubjects.Name = "dataGridViewSubjects";
            dataGridViewSubjects.Size = new Size(553, 257);
            dataGridViewSubjects.TabIndex = 8;
            dataGridViewSubjects.CellDoubleClick += dataGridViewSubjects_CellDoubleClick;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(137, 28);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(422, 23);
            textBox1.TabIndex = 9;
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(label5);
            groupBox3.Controls.Add(textBoxId);
            groupBox3.Controls.Add(button1);
            groupBox3.Controls.Add(label4);
            groupBox3.Controls.Add(textBoxGrade);
            groupBox3.Controls.Add(labelSubject);
            groupBox3.Controls.Add(label6);
            groupBox3.Controls.Add(labelStudentName);
            groupBox3.Controls.Add(label3);
            groupBox3.Location = new Point(378, 444);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(515, 184);
            groupBox3.TabIndex = 2;
            groupBox3.TabStop = false;
            groupBox3.Text = "Subject Details";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(82, 79);
            label5.Name = "label5";
            label5.Size = new Size(20, 15);
            label5.TabIndex = 8;
            label5.Text = "Id:";
            // 
            // textBoxId
            // 
            textBoxId.Location = new Point(129, 76);
            textBoxId.Name = "textBoxId";
            textBoxId.Size = new Size(100, 23);
            textBoxId.TabIndex = 7;
            // 
            // button1
            // 
            button1.Location = new Point(419, 145);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 6;
            button1.Text = "Save";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(82, 108);
            label4.Name = "label4";
            label4.Size = new Size(41, 15);
            label4.TabIndex = 5;
            label4.Text = "Grade:";
            // 
            // textBoxGrade
            // 
            textBoxGrade.Location = new Point(129, 105);
            textBoxGrade.Name = "textBoxGrade";
            textBoxGrade.Size = new Size(100, 23);
            textBoxGrade.TabIndex = 4;
            // 
            // labelSubject
            // 
            labelSubject.AutoSize = true;
            labelSubject.Location = new Point(129, 55);
            labelSubject.Name = "labelSubject";
            labelSubject.Size = new Size(38, 15);
            labelSubject.TabIndex = 3;
            labelSubject.Text = "label4";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(25, 55);
            label6.Name = "label6";
            label6.Size = new Size(96, 15);
            label6.TabIndex = 2;
            label6.Text = "Selected Subject:";
            // 
            // labelStudentName
            // 
            labelStudentName.AutoSize = true;
            labelStudentName.Location = new Point(129, 29);
            labelStudentName.Name = "labelStudentName";
            labelStudentName.Size = new Size(38, 15);
            labelStudentName.TabIndex = 1;
            labelStudentName.Text = "label4";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(25, 29);
            label3.Name = "label3";
            label3.Size = new Size(98, 15);
            label3.TabIndex = 0;
            label3.Text = "Selected Student:";
            // 
            // labelStudentId
            // 
            labelStudentId.AutoSize = true;
            labelStudentId.Location = new Point(922, 473);
            labelStudentId.Name = "labelStudentId";
            labelStudentId.Size = new Size(38, 15);
            labelStudentId.TabIndex = 2;
            labelStudentId.Text = "label4";
            labelStudentId.Visible = false;
            // 
            // labelSubjectId
            // 
            labelSubjectId.AutoSize = true;
            labelSubjectId.Location = new Point(922, 499);
            labelSubjectId.Name = "labelSubjectId";
            labelSubjectId.Size = new Size(38, 15);
            labelSubjectId.TabIndex = 3;
            labelSubjectId.Text = "label4";
            labelSubjectId.Visible = false;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(386, 321);
            label7.Name = "label7";
            label7.Size = new Size(179, 15);
            label7.TabIndex = 11;
            label7.Text = "*Double click to select a student.";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(380, 321);
            label8.Name = "label8";
            label8.Size = new Size(177, 15);
            label8.TabIndex = 12;
            label8.Text = "*Double click to select a subject.";
            // 
            // FormAddStudentSubject
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1243, 668);
            Controls.Add(labelSubjectId);
            Controls.Add(labelStudentId);
            Controls.Add(groupBox3);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Name = "FormAddStudentSubject";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "FormAddStudentSubject";
            Load += FormAddStudentSubject_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridViewStudents).EndInit();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridViewSubjects).EndInit();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox groupBox1;
        private Label label2;
        private DataGridView dataGridViewStudents;
        private TextBox textBoxSearch;
        private GroupBox groupBox2;
        private Label label1;
        private DataGridView dataGridViewSubjects;
        private TextBox textBox1;
        private GroupBox groupBox3;
        private Label labelSubject;
        private Label label6;
        private Label labelStudentName;
        private Label label3;
        private Label labelStudentId;
        private Label labelSubjectId;
        private Button button1;
        private Label label4;
        private TextBox textBoxGrade;
        private Label label5;
        private TextBox textBoxId;
        private Label label7;
        private Label label8;
    }
}