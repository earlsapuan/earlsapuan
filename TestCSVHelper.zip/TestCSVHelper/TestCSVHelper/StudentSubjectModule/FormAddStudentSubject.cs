﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TestCSVHelper.DataAccess;
using TestCSVHelper.Models;

namespace TestCSVHelper.StudentSubjectModule
{
    public partial class FormAddStudentSubject : Form
    {
        public FormAddStudentSubject()
        {
            InitializeComponent();
        }

        private void FormAddStudentSubject_Load(object sender, EventArgs e)
        {
            LoadStudents();
            LoadSubjects();
        }

        private void LoadStudents()
        {
            List<Student> persons = new List<Student>();
            persons = StudentData.GetAllStudents();

            dataGridViewStudents.DataSource = null;
            dataGridViewStudents.DataSource = persons;
        }

        private void LoadSubjects()
        {
            List<Subject> persons = new List<Subject>();
            persons = SubjectData.GetAllSubjects();

            dataGridViewSubjects.DataSource = null;
            dataGridViewSubjects.DataSource = persons;
        }

        private void dataGridViewStudents_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridViewStudents_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            //This will get the index 0 of the selected row of the datagridview in this case the StudentId
            labelStudentId.Text = dataGridViewStudents.CurrentRow.Cells[0].Value.ToString();
            //This will get the index 2 of the selected row of the datagridview in this case the StudentLastName
            labelStudentName.Text = dataGridViewStudents.CurrentRow.Cells[2].Value.ToString();
        }

        private void dataGridViewSubjects_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            //This will get the index 0 of the selected row of the datagridview in this case the SubjectId
            labelSubjectId.Text = dataGridViewSubjects.CurrentRow.Cells[0].Value.ToString();
            //This will get the index 1 of the selected row of the datagridview in this case the SubjectName
            labelSubject.Text = dataGridViewSubjects.CurrentRow.Cells[1].Value.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            StudentSubject studentSubject = new StudentSubject { StudentSubjectId = Convert.ToInt32( textBoxId.Text) , StudentId = Convert.ToInt32 (labelStudentId.Text), SubjectId = Convert.ToInt32(labelSubjectId.Text), Grade = Convert.ToInt32(textBoxGrade.Text) };

            StudentSubjectData.AddStudentSubject(studentSubject);
            
            DialogResult = DialogResult.OK;
        
        }
    }
}
