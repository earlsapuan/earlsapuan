﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TestCSVHelper.View_Models;

namespace TestCSVHelper.StudentModule
{
    public partial class FormViewGrades : Form
    {
        //Since a Form is also a Class we can add properties to it that can used to pass data from 1 form to another.
        public Student Student { get; set; }
        public List<ViewStudentSubject> StudentSubjects { get; set; }
        public FormViewGrades()
        {
            InitializeComponent();
            StudentSubjects = new List<ViewStudentSubject>();
        }

        private void FormViewGrades_Load(object sender, EventArgs e)
        {
            label2StudentName.Text = Student.LastName;

            dataGridViewGrades.DataSource = null;
            dataGridViewGrades.DataSource = StudentSubjects;
        }
    }
}
