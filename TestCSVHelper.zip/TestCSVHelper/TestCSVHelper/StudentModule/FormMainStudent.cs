using CsvHelper;
using System.Globalization;
using System;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using TestCSVHelper.DataAccess;
using TestCSVHelper.Models;
using TestCSVHelper.StudentModule;
using System.Windows.Forms;

namespace TestCSVHelper
{
    public partial class FormMainStudent : Form
    {
        public FormMainStudent()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FormAddStudent formAddStudent = new FormAddStudent();
            if (formAddStudent.ShowDialog() == DialogResult.OK)
            {
                LoadStudents();
            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            LoadStudents();
        }

        private void LoadStudents()
        {
            List<Student> persons = new List<Student>();
            persons = StudentData.GetAllStudents();

            dataGridViewStudents.DataSource = null;
            dataGridViewStudents.DataSource = persons;
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBoxSearch_TextChanged(object sender, EventArgs e)
        {
            List<Student> persons = new List<Student>();
            persons = StudentData.GetAllStudentsNameSearch(textBoxSearch.Text);

            dataGridViewStudents.DataSource = null;
            dataGridViewStudents.DataSource = persons;
        }

        private void dataGridViewStudents_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            FormViewGrades formViewGrades = new FormViewGrades();
            //Student and StudentSubjects are properties of the form that we can use to pass data from 1 form to another.
            //dataGridViewStudents.CurrentRow.Cells[0].Value means that we will get the index 0 of the selected row of the datagridview. In this case StudentId
            formViewGrades.Student = StudentData.GetStudentById(Convert.ToInt32(dataGridViewStudents.CurrentRow.Cells[0].Value));
            formViewGrades.StudentSubjects = StudentSubjectData.GetAllSubjectsByStudent(Convert.ToInt32(dataGridViewStudents.CurrentRow.Cells[0].Value));

            formViewGrades.ShowDialog();
        }
    }
}
