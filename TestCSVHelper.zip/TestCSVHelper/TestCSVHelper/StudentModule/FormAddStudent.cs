﻿using CsvHelper;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TestCSVHelper.DataAccess;
using TestCSVHelper.Models;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace TestCSVHelper
{
    public partial class FormAddStudent : Form
    {
        public FormAddStudent()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            Student student = new Student { StudentId = Convert.ToInt32( textBoxStudentId.Text), FirstName = textBoxFirstName.Text, LastName = textBoxLastName.Text };

            StudentData.AddStudent(student);

            DialogResult = DialogResult.OK;
        }

    }
}
