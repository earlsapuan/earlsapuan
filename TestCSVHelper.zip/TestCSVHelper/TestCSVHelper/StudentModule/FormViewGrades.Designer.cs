﻿namespace TestCSVHelper.StudentModule
{
    partial class FormViewGrades
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2StudentName = new Label();
            groupBox1 = new GroupBox();
            dataGridViewGrades = new DataGridView();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridViewGrades).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(49, 22);
            label1.Name = "label1";
            label1.Size = new Size(51, 15);
            label1.TabIndex = 0;
            label1.Text = "Student:";
            // 
            // label2StudentName
            // 
            label2StudentName.AutoSize = true;
            label2StudentName.Location = new Point(106, 22);
            label2StudentName.Name = "label2StudentName";
            label2StudentName.Size = new Size(38, 15);
            label2StudentName.TabIndex = 1;
            label2StudentName.Text = "label2";
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(dataGridViewGrades);
            groupBox1.Location = new Point(49, 60);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(416, 202);
            groupBox1.TabIndex = 2;
            groupBox1.TabStop = false;
            groupBox1.Text = "Grade List";
            // 
            // dataGridViewGrades
            // 
            dataGridViewGrades.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewGrades.Location = new Point(6, 22);
            dataGridViewGrades.Name = "dataGridViewGrades";
            dataGridViewGrades.RowTemplate.Height = 25;
            dataGridViewGrades.Size = new Size(370, 150);
            dataGridViewGrades.TabIndex = 0;
            // 
            // FormViewGrades
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(504, 283);
            Controls.Add(groupBox1);
            Controls.Add(label2StudentName);
            Controls.Add(label1);
            Name = "FormViewGrades";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "FormViewGrades";
            Load += FormViewGrades_Load;
            groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridViewGrades).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2StudentName;
        private GroupBox groupBox1;
        private DataGridView dataGridViewGrades;
    }
}