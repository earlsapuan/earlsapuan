﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TestCSVHelper.DataAccess;
using TestCSVHelper.Models;

namespace TestCSVHelper.SubjectModule
{
    public partial class FormMainSubjects : Form
    {
        public FormMainSubjects()
        {
            InitializeComponent();
        }

        private void FormMainSubjects_Load(object sender, EventArgs e)
        {
            LoadSubjects();
        }
        private void LoadSubjects()
        {
            List<Subject> persons = new List<Subject>();
            persons = SubjectData.GetAllSubjects();

            dataGridViewSubjects.DataSource = null;
            dataGridViewSubjects.DataSource = persons;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FormAddSubject formAddSubject = new FormAddSubject();
            if (formAddSubject.ShowDialog() == DialogResult.OK)
            {
                LoadSubjects();
            }
        }
    }
}
