﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TestCSVHelper.DataAccess;
using TestCSVHelper.Models;

namespace TestCSVHelper.SubjectModule
{
    public partial class FormAddSubject : Form
    {
        public FormAddSubject()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Subject subject = new Subject { SubjectId = Convert.ToInt32(textBoxSubjectId.Text), SubjectName = textBoxSubjectName.Text };

            SubjectData.AddSubject(subject);

            DialogResult = DialogResult.OK;
        }
    }
}
