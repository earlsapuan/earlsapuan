﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestCSVHelper.View_Models
{
    public class ViewStudentSubject
    {
        public string Subject { get; set; }
        public int Grade { get; set; }
    }
}
